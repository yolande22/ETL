###############################################
#                                             #
# PROJET DE CAPTURE ET NOTTOIYAGE DE DONNEES  #
#                                             #
# Auteur: KWEDOM Annick Yolande               #
#                                             #
###############################################


#Importation des librairies
import mysql, mysql.connector
import csv as csv
import json

try:
	#connexion a MYSQL
	con =mysql.connector.connect(user='root', password='', host='localhost', database='bdclients')

	# creation de la table de Merging
	cursor = con.cursor()
	cursor.execute("""
	create table if not exists clients (
		numKey int AUTO_INCREMENT PRIMARY KEY,
		id INT NOT NULL,
		first_name VARCHAR(50) NOT NULL,
		last_name VARCHAR(50) NOT NULL,
		email VARCHAR(50) NOT NULL,
		gender VARCHAR(15) NOT NULL,
		ville VARCHAR(50) NOT NULL,
		srcfile VARCHAR(25) NOT NULL
	)
	"""
	)

	# validation de la table de merging
	con.commit()

	#selections des donnees de la table sql
	requete = "select * from client_DATA"
	cursor.execute(requete) #obtenir les enregistrements
	lignes = cursor.fetchall()

	try:
		#parcours des enregistrements potentiels
		for lines in lignes:
			#transforme le tuple lines en liste pour pouvoir le modifier
			line= list(lines)

			# traitement des  villes manquantes
			if  (line[5] == ''):
				line[5] = 'VILLE_INCONNUE'

			#traitement de la variable gender
			if line[4] in ('F', 'f','FEMELLE', 'femelle', 'Femelle', 'Female', 'female'):
				line[4] = 'Femelle'
			elif line[4] in ('M', 'm', 'MALE', 'male', 'Male'):
				line[4] = 'Male'
			else:
				line[4] = 'SEXE_INCONNU'

			# insertion des donnees dans la table de merging
			commande = """insert into clients(id, first_name, last_name, email, gender, ville, srcfile) values(%s,%s,%s,%s,%s,%s,%s)"""
			cursor.execute(commande,[line[0], line[1], line[2], line[3], line[4], line[5], 'sqlfile'])

		# validation de l'insertion dans la table de merging
		con.commit()

	#Gestion des exceptions de chargement du fichier sql
	except mysql.OperationalError:
		print("Impossible de charger le fichier sql ...")


	#fichier csv

	#lecture du fichier week_cust.csv
	readdata = csv.reader(open("week_cust.csv"))
	data = []

	try:
		#transfert des donnees dans une liste
		for row in readdata:
			data.append(row)
		Header = data[0]
		data.pop(0)

		#Insertion des donnees du fichier csv dans la table de merging
		for row in data:

			# traitement des  villes manquantes
			if (row[5] == ''):
				row[5] = 'VILLE_INCONNUE'

			#traitement de la variable gender
			if row[4] in ('F', 'f','FEMELLE', 'femelle', 'Femelle', 'Female', 'female'):
				row[4] = 'Femelle'
			elif row[4] in ('M', 'm', 'MALE', 'male', 'Male'):
				row[4] = 'Male'
			else:
				row[4] = 'SEXE_INCONNU'

			# insertion des donnees dans la table de merging
			commande = """insert into clients(id, first_name, last_name, email, gender, ville, srcfile) values(%s,%s,%s,%s,%s,%s,%s)"""
			cursor.execute(commande,[row[0], row[1], row[2], row[3], row[4], row[5], 'csvfile'])

		# validation de l'insertion dans la table de merging
		con.commit()

	#Gestion des exceptions de chargement du fichier csv
	except mysql.OperationalError:
		print("Impossible de charger le fichier csv ...")

	# fichier json

	json_data=open('cust_data.json')
	data = json.load(json_data)

	try:
		for ligne in data:

			# test de traitement des donnees manquantes
			if 'ville' not in ligne.keys():
				ville = "VILLE_INCONNUE"
			elif 'gender' not in ligne.keys():
				sexe = "SEXE_INCONNU"
			else:
				sexe = ligne["gender"]
				ville = ligne['ville']

			#traitement de la variable gender
			if sexe in ('F', 'f','FEMELLE', 'femelle', 'Femelle', 'Female', 'female'):
				sexe = 'Femelle'
			elif sexe in ('M', 'm', 'MALE', 'male', 'Male'):
				sexe = 'Male'
			else:
				sexe = 'SEXE_INCONNU'

			# insertion des donnees dans la table de merging
			commande = """insert into clients(id, first_name, last_name, email, gender, ville, srcfile) values(%s,%s,%s,%s,%s,%s,%s)"""
			cursor.execute(commande, [ligne['id'], ligne['first_name'], ligne['last_name'], ligne['email'], sexe, ville, 'jsonfile'])

		# validation de l'insertion dans la table de merging
		con.commit()

	#Gestion des exceptions de chargement du fichier json et cloture du fichier
	except mysql.OperationalError:
		print("Impossible de charger le fichier json ...")
	finally:
		json_data.close()

#Gestion des exceptions de connection a Mysql
except mysql.OperationalError:
    print("Erreur systeme ...")
finally:
    con.close()

#FIN
